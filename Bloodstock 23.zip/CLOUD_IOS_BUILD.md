# DiazBloodstock iOS cloud build

Prepared for a cloud iOS build with Codemagic, so a local Mac is not required.

Bundle ID:
app.floot.u4ef0e3025d0b4bb6aa5295f58ef014d4

The included workflow installs dependencies, installs CocoaPods, configures App Store signing,
builds the IPA, and uploads it to TestFlight after App Store Connect is linked.

No Apple password or private API key is stored in this package.
